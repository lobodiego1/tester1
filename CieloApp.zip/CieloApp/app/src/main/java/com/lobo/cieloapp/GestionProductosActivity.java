package com.lobo.cieloapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class GestionProductosActivity extends AppCompatActivity {

    private RequestQueue queue;

    EditText editTextNombre, editTextDescripcion, editTextPrecio;
    Button btnAccionProducto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_productos);

        queue = Volley.newRequestQueue(this);
        editTextNombre = findViewById(R.id.editTextNombre);
        editTextDescripcion = findViewById(R.id.editTextDescripcion);
        editTextPrecio = findViewById(R.id.editTextPrecio);
        btnAccionProducto = findViewById(R.id.btnAccionProducto);

        editTextNombre.setText(getIntent().getStringExtra("nombre"));
        editTextDescripcion.setText(getIntent().getStringExtra("descripcion"));
        editTextPrecio.setText(getIntent().getStringExtra("precio"));

        btnAccionProducto.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                realizarPost(getIntent().getStringExtra("idProducto"));
            }
        });
    }

    public void realizarPost(String idProducto) {
        Map<String, String> params = new HashMap<String, String>();
        String url = "http://192.168.0.119:8080/agregar-producto";

        if(!"".equals(idProducto)){
            url = "http://192.168.0.119:8080/editar-producto";
            params.put("idProducto", idProducto);
        }
        params.put("nombre", this.editTextNombre.getText().toString());
        params.put("descripcion", editTextDescripcion.getText().toString());
        params.put("precio", editTextPrecio.getText().toString());
        params.put("inventario", "0");


        JSONObject jsonObj = new JSONObject(params);

        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObj, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                MyToast.showToastInfo(GestionProductosActivity.this, "Registro actualizado");
                GestionProductosActivity.super.onBackPressed();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                MyToast.showToastInfo(GestionProductosActivity.this, "product3o:"+error.getMessage());
            }
        });
        queue.add(postRequest);
    }
}