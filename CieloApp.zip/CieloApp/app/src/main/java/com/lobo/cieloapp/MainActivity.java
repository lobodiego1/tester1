package com.lobo.cieloapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener{

    BottomNavigationView bottomNavigationView;

    HomeFragment homeFragment = new HomeFragment();
    ProductosFragment productosFragment = new ProductosFragment();
    ClientesFragment clientesFragment = new ClientesFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Bundle bundle = new Bundle();
        bundle.putString("idCliente", "1");
        homeFragment.setArguments(bundle);
        productosFragment.setArguments(bundle);
        clientesFragment.setArguments(bundle);


        bottomNavigationView
                = findViewById(R.id.bottomNavigationView);

        bottomNavigationView
                .setOnNavigationItemSelectedListener(this);
        bottomNavigationView.setSelectedItemId(R.id.itemHome);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.itemHome){
            getSupportFragmentManager().beginTransaction().replace(R.id.flFragment, homeFragment).commit();
            return true;
        }
        if(item.getItemId() == R.id.itemProductos){
            getSupportFragmentManager().beginTransaction().replace(R.id.flFragment, productosFragment).commit();
            return true;
        }
        if(item.getItemId() == R.id.itemClientes){
            getSupportFragmentManager().beginTransaction().replace(R.id.flFragment, clientesFragment).commit();
            return true;
        }

        return false;
    }
}