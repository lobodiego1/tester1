package com.lobo.cieloapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class GestionClientesActivity extends AppCompatActivity {

    private RequestQueue queue;

    EditText editTextNombre, editTextApellidos;
    Button btnAccionClientes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_clientes);

        queue = Volley.newRequestQueue(this);
        editTextNombre = findViewById(R.id.editTextNombreCliente);
        editTextApellidos = findViewById(R.id.editTextApellidos);

        btnAccionClientes = findViewById(R.id.btnAccionClientes);

        editTextNombre.setText(getIntent().getStringExtra("nombre"));
        editTextApellidos.setText(getIntent().getStringExtra("apellidos"));

        btnAccionClientes.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                realizarPost(getIntent().getStringExtra("idCliente"));
            }
        });
    }


    public void realizarPost(String idCliente) {
        Map<String, String> params = new HashMap<String, String>();
        String url = "http://192.168.0.119:8080/agregar-cliente";

        if(!"".equals(idCliente)){
            url = "http://192.168.0.119:8080/editar-cliente";
            params.put("idClientes", idCliente);
        }
        params.put("nombre", this.editTextNombre.getText().toString());
        //params.put("apellidos", editTextDescripcion.getText().toString());


        JSONObject jsonObj = new JSONObject(params);

        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObj, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                MyToast.showToastInfo(GestionClientesActivity.this, "Registro actualizado");
                GestionClientesActivity.super.onBackPressed();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                MyToast.showToastInfo(GestionClientesActivity.this, "product3o:"+error.getMessage());
            }
        });
        queue.add(postRequest);
    }
}