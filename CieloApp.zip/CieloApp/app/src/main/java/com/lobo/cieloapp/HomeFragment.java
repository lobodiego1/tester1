package com.lobo.cieloapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class HomeFragment extends Fragment implements SelectListener{

    RecyclerView rv1;
    private RequestQueue queue;
    JSONArray mJsonArrayProperty;

    Button btnRealizarVenta;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onItemClicked(ListenerBean myModel) {
        Intent i = new Intent(getActivity(), DetalleCompraActivity.class);
        i.putExtra("idDetalleVenta", myModel.getId());
        i.putExtra("nombreCompleto", myModel.getNombre());
        i.putExtra("fechaEfectiva", myModel.getIdCliente());
        i.putExtra("estatusPedido", myModel.getStatusPedido());

        startActivity(i);
    }

    @Override
    public void onItemClickedAux(ListenerBean myModel) {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        queue = Volley.newRequestQueue(getActivity());
    }

    private class AdaptadorVentas extends RecyclerView.Adapter<HomeFragment.AdaptadorVentas.AdaptadorVentassHolder>{

        private SelectListener listener;

        public AdaptadorVentas(SelectListener listener) {
            this.listener = listener;
        }

        @NonNull
        @Override
        public HomeFragment.AdaptadorVentas.AdaptadorVentassHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new HomeFragment.AdaptadorVentas.AdaptadorVentassHolder(getLayoutInflater().inflate(R.layout.layout_card_ventas, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull HomeFragment.AdaptadorVentas.AdaptadorVentassHolder holder, int position) {
            holder.imprimir(position);
        }

        @Override
        public int getItemCount() {
            return mJsonArrayProperty.length();
        }

        class AdaptadorVentassHolder extends RecyclerView.ViewHolder{
            TextView txtViewNombreCliente, txtViewFechaCompra;
            Button btnVerVenta;

            CardView card;
            public AdaptadorVentassHolder(@NonNull View itemView){
                super(itemView);

                txtViewNombreCliente = itemView.findViewById(R.id.txtViewNombreCliente);
                txtViewFechaCompra = itemView.findViewById(R.id.txtViewFechaCompra);
                btnVerVenta = itemView.findViewById(R.id.btnVerVenta);
                card = itemView.findViewById(R.id.cardViewVentas);
            }

            public void imprimir(int p) {

                try {
                    JSONObject mJsonObjectProperty = mJsonArrayProperty.getJSONObject(p);

                    txtViewNombreCliente.setText(mJsonObjectProperty.getString("nombreCliente"));
                    txtViewFechaCompra.setText(mJsonObjectProperty.getString("fechaEmitida"));
                    btnVerVenta.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ListenerBean lista = new ListenerBean();
                            try {
                                lista.setId(mJsonObjectProperty.getString("idDetalleVenta"));
                                lista.setIdCliente(mJsonObjectProperty.getString("fechaEmitida"));
                                lista.setNombre(mJsonObjectProperty.getString("nombreCliente"));
                                lista.setStatusPedido(mJsonObjectProperty.getString("idTipoPago"));
                                //fechaEmitida
                                //nombreCliente
                                        //idTipoPago
                                listener.onItemClicked(lista);
                            } catch (JSONException e) {
                                Toast.makeText(getActivity(), "try2:"+e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                } catch (JSONException e) {
                    Toast.makeText(getActivity(), "try1:"+e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                }
            }

        }
    }
    public void realizarPost(String idCliente) {
        String url = "http://192.168.0.119:8080/consultas-ventas";

        Map<String, String> params = new HashMap<String, String>();
        params.put("idCliente", idCliente);

        JSONObject jsonObj = new JSONObject(params);

        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObj, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    mJsonArrayProperty = response.getJSONArray("listResponse");
                    rv1.setAdapter(new HomeFragment.AdaptadorVentas(HomeFragment.this));

                } catch (JSONException e) {
                    MyToast.showToastInfo(getActivity(), "e:"+e.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                MyToast.showToastInfo(getActivity(), "product3o:"+error.getMessage());
            }
        });
        queue.add(postRequest);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View Re = inflater.inflate(R.layout.fragment_home, container, false);
        rv1 = Re.findViewById(R.id.recyclerViewVentas);
        btnRealizarVenta = Re.findViewById(R.id.btnRealizarVenta);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(Re.getContext());
        rv1.setLayoutManager(linearLayoutManager);

        realizarPost("1");

        btnRealizarVenta.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), ComprasActivity.class);
                i.putExtra("idProducto", "");

                startActivity(i);
            }
        });

        return Re;
    }
}