package com.lobo.cieloapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ComprasActivity extends AppCompatActivity implements SelectListener{

    RecyclerView rv1;
    private RequestQueue queue;
    JSONArray mJsonArrayProperty;

    Button btnRealizarVenta, btnBuscarClientes;
    TextView  textViewNombreCliente, textViewTotalCompra;

    @Override
    public void onItemClickedAux(ListenerBean myModel) {}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compras);

        queue = Volley.newRequestQueue(this);
        rv1 = findViewById(R.id.recyclerViewCompras);
        btnRealizarVenta = findViewById(R.id.btnRealizarVenta);
        btnBuscarClientes = findViewById(R.id.btnBuscarClientes);
        textViewNombreCliente = findViewById(R.id.textViewNombreCliente);
        textViewTotalCompra = findViewById(R.id.textViewTotalCompra);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        rv1.setLayoutManager(linearLayoutManager);

        this.mostrarCarritoPendiente();



        btnRealizarVenta.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                realizarVentaAccion();
            }
        });

        btnBuscarClientes.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

            }
        });



    }

    @Override
    public void onItemClicked(ListenerBean bean) {
        this.eliminarProducto(bean.getId(), bean.getIdProducto());
        //MyToast.showToastInfo(ComprasActivity.this, "clic:"+myModel.getId());
    }


    private class AdaptadorCompras extends RecyclerView.Adapter<ComprasActivity.AdaptadorCompras.AdaptadorComprassHolder>{

        private SelectListener listener;

        public AdaptadorCompras(SelectListener listener) {
            this.listener = listener;
        }

        @NonNull
        @Override
        public ComprasActivity.AdaptadorCompras.AdaptadorComprassHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ComprasActivity.AdaptadorCompras.AdaptadorComprassHolder(getLayoutInflater().inflate(R.layout.layout_card_carrito_producto, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull ComprasActivity.AdaptadorCompras.AdaptadorComprassHolder holder, int position) {
            holder.imprimir(position);
        }

        @Override
        public int getItemCount() {
            return mJsonArrayProperty.length();
        }

        class AdaptadorComprassHolder extends RecyclerView.ViewHolder{
            TextView txtViewNombrePCarrito;
            Button btnEliminarPCarrito;

            CardView card;
            public AdaptadorComprassHolder(@NonNull View itemView){
                super(itemView);
                txtViewNombrePCarrito = itemView.findViewById(R.id.txtViewNombrePCarrito);
                btnEliminarPCarrito = itemView.findViewById(R.id.btnEliminarPCarrito);
                card = itemView.findViewById(R.id.cardViewCarritoProducto);
            }

            public void imprimir(int p) {

                try {
                    JSONObject mJsonObjectProperty = mJsonArrayProperty.getJSONObject(p);

                    //idProducto precio nombre idProductosCarritosPK=1
                    txtViewNombrePCarrito.setText(mJsonObjectProperty.getString("nombre") );
                    btnEliminarPCarrito.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ListenerBean lista = new ListenerBean();

                            try {
                                lista.setId(mJsonObjectProperty.getString("idProductosCarritosPk"));
                                lista.setIdProducto(mJsonObjectProperty.getString("idProducto"));
                            } catch (JSONException e) {
                                MyToast.showToastInfo(ComprasActivity.this, "e:"+e.getMessage());
                            }
                            
                            listener.onItemClicked(lista);

                        }
                    });

                } catch (JSONException e) {
                    Toast.makeText(ComprasActivity.this, "try1:"+e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                }
            }

        }
    }


    public void eliminarProducto(String idProductoCarrito, String idProducto) {
        String url = "http://192.168.0.119:8080/eliminar-producto-carrito";

        Map<String, String> params = new HashMap<>();
        params.put("idProductosCarritosPk", idProductoCarrito);
        params.put("idProducto", idProducto);
        JSONObject jsonObj = new JSONObject(params);
        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObj, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                    mostrarCarritoPendiente();
                    MyToast.showToastInfo(ComprasActivity.this, "e:"+response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                MyToast.showToastInfo(ComprasActivity.this, "product3o:"+error.getMessage());
            }
        });
        queue.add(postRequest);
    }


    public void realizarVentaAccion() {
        String url = "http://192.168.0.119:8080/comprar-carrito";

        Map<String, String> params = new HashMap<>();
        params.put("idCliente", "1");

        JSONObject jsonObj = new JSONObject(params);
        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObj, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                MyToast.showToastInfo(ComprasActivity.this, "e:"+response);
                ComprasActivity.super.onBackPressed();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                MyToast.showToastInfo(ComprasActivity.this, "product3o:"+error.getMessage());
            }
        });
        queue.add(postRequest);
    }




    public void mostrarCarritoPendiente() {
        String url = "http://192.168.0.119:8080/get-carrito-activo";

        Map<String, String> params = new HashMap<>();
        params.put("nombre", "");

        JSONObject jsonObj = new JSONObject(params);

        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObj, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    mJsonArrayProperty = response.getJSONArray("listResponse");
                    rv1.setAdapter(new ComprasActivity.AdaptadorCompras(ComprasActivity.this));
                    MyToast.showToastInfo(ComprasActivity.this, "res:"+mJsonArrayProperty);
                } catch (JSONException e) {
                    MyToast.showToastInfo(ComprasActivity.this, "e:"+e.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                MyToast.showToastInfo(ComprasActivity.this, "product3o:"+error.getMessage());
            }
        });
        queue.add(postRequest);
    }

}