package com.lobo.cieloapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DetalleCompraActivity extends AppCompatActivity {

    RecyclerView rv1;
    JSONArray mJsonArrayProperty;
    private RequestQueue queue;
    ListView listViewProductos, listViewAbonos;

    TextView txtNombreCompleto, txtFechaCompra, txtEstatusPedido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_compra);
        queue = Volley.newRequestQueue(this);


        listViewProductos = (ListView)findViewById(R.id.listViewProductos);
        listViewAbonos = (ListView)findViewById(R.id.listViewAbonos);

        txtNombreCompleto = findViewById(R.id.txtNombreCompleto);
        txtFechaCompra = findViewById(R.id.txtFechaCompra);
        txtEstatusPedido = findViewById(R.id.txtEstatusPedido);

        String idDetalleVenta = getIntent().getStringExtra("idDetalleVenta");
        txtNombreCompleto.setText(getIntent().getStringExtra("nombreCompleto"));
        txtFechaCompra.setText(getIntent().getStringExtra("fechaEfectiva"));
        txtEstatusPedido.setText(getIntent().getStringExtra("estatusPedido"));



        postBuscarDetalleCompra(idDetalleVenta);
    }

    public void postBuscarDetalleCompra(String idDetalleVenta) {
        String url = "http://192.168.0.119:8080/consultas-ventas-productos";
        Map<String, String> params = new HashMap<String, String>();

        params.put("idDetalleVenta", idDetalleVenta);

        JSONObject jsonObj = new JSONObject(params);
        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObj, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                //MyToast.showToastInfo(DetallesActivity.this,"Porducto Agregado al carrito");
                //productos listas
                try {
                    JSONArray listaProductos = response.getJSONArray("listResponse");
                    JSONArray listaAbonos = response.getJSONArray("listResponseDos");


                    ArrayList<String> productoList = new ArrayList<String>();

                    for(int i=0; i<listaProductos.length(); i++){
                        JSONObject objArreg = listaProductos.getJSONObject(i);
                        productoList.add(objArreg.getString("nombre") + " | " + objArreg.getString("cantidad") + " | " + objArreg.getString("precio"));

                    }


                    ArrayAdapter<String> arrayAdapterProductos = new ArrayAdapter<String>(DetalleCompraActivity.this, R.layout.activity_listview_producto, R.id.textViewNombre, productoList);
                    listViewProductos.setAdapter(arrayAdapterProductos);


                    ArrayList<String> abonosList = new ArrayList<String>();

                    for(int i=0; i<listaAbonos.length(); i++){
                        JSONObject objArreg = listaAbonos.getJSONObject(i);
                        abonosList.add(objArreg.getString("fecha") + " | $ " + objArreg.getString("cantidad"));
                    }


                    ArrayAdapter<String> arrayAdapterAbonos = new ArrayAdapter<String>(DetalleCompraActivity.this, R.layout.activity_listview_producto, R.id.textViewNombre, abonosList);
                    listViewAbonos.setAdapter(arrayAdapterAbonos);



                } catch (JSONException e) {
                    MyToast.showToastInfo(DetalleCompraActivity.this,e.getMessage());
                }
                //abonos listas

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                MyToast.showToastAlert(DetalleCompraActivity.this,"Ocurrio un Error");
            }
        });

        queue.add(postRequest);
    }
}