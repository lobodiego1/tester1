package com.lobo.cieloapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ClientesFragment extends Fragment implements SelectListener {

    RecyclerView rv1;
    private RequestQueue queue;
    JSONArray mJsonArrayProperty;

    Button btnAgregarCliente;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        queue = Volley.newRequestQueue(getActivity());
    }

    @Override
    public void onItemClicked(ListenerBean myModel) {
        Intent i = new Intent(getActivity(), GestionClientesActivity.class);
        i.putExtra("idCliente", myModel.getId());

        i.putExtra("nombre", myModel.getNombre());
        i.putExtra("apellidos", myModel.getStatusPedido());


        startActivity(i);
    }

    @Override
    public void onItemClickedAux(ListenerBean myModel) {}

    private class AdaptadorClientes extends RecyclerView.Adapter<ClientesFragment.AdaptadorClientes.AdaptadorClientessHolder>{

        private SelectListener listener;

        public AdaptadorClientes(SelectListener listener) {
            this.listener = listener;
        }

        @NonNull
        @Override
        public ClientesFragment.AdaptadorClientes.AdaptadorClientessHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ClientesFragment.AdaptadorClientes.AdaptadorClientessHolder(getLayoutInflater().inflate(R.layout.layout_card_clientes, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull ClientesFragment.AdaptadorClientes.AdaptadorClientessHolder holder, int position) {
            holder.imprimir(position);
        }

        @Override
        public int getItemCount() {
            return mJsonArrayProperty.length();
        }

        class AdaptadorClientessHolder extends RecyclerView.ViewHolder{
            TextView txtViewNombreCliente, txtViewApellidos;
            Button btnVerCliente;

            CardView card;
            public AdaptadorClientessHolder(@NonNull View itemView){
                super(itemView);

                txtViewNombreCliente = itemView.findViewById(R.id.txtViewNombreCliente);
                txtViewApellidos = itemView.findViewById(R.id.txtViewApellidos);

                btnVerCliente = itemView.findViewById(R.id.btnVerCliente);
                card = itemView.findViewById(R.id.cardViewClientes);
            }

            public void imprimir(int p) {

                try {
                    JSONObject mJsonObjectProperty = mJsonArrayProperty.getJSONObject(p);

                    txtViewNombreCliente.setText(mJsonObjectProperty.getString("nombre"));
                    txtViewApellidos.setText("");
                    btnVerCliente.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ListenerBean lista = new ListenerBean();

                            try {
                                lista.setId(mJsonObjectProperty.getString("idClientes"));
                                lista.setNombre(mJsonObjectProperty.getString("nombre"));
                                lista.setStatusPedido("");
                            } catch (JSONException e) {
                                MyToast.showToastInfo(getActivity(), "e:"+e.getMessage());
                            }


                                listener.onItemClicked(lista);

                        }
                    });

                } catch (JSONException e) {
                    Toast.makeText(getActivity(), "try1:"+e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                }
            }

        }
    }
    

    public void cargarClientesTodos() {
        String url = "http://192.168.0.119:8080/busqueda-cliente";

        Map<String, String> params = new HashMap<String, String>();
        params.put("nombre", "");

        JSONObject jsonObj = new JSONObject(params);

        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObj, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    mJsonArrayProperty = response.getJSONArray("listResponse");
                    rv1.setAdapter(new ClientesFragment.AdaptadorClientes(ClientesFragment.this));

                } catch (JSONException e) {
                    MyToast.showToastInfo(getActivity(), "e:"+e.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                MyToast.showToastInfo(getActivity(), "product3o:"+error.getMessage());
            }
        });
        queue.add(postRequest);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View Re = inflater.inflate(R.layout.fragment_clientes, container, false);
        rv1 = Re.findViewById(R.id.recyclerViewClientes);
        btnAgregarCliente = Re.findViewById(R.id.btnAgregarCliente);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(Re.getContext());
        rv1.setLayoutManager(linearLayoutManager);

        cargarClientesTodos();

        btnAgregarCliente.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), GestionProductosActivity.class);
                i.putExtra("idCliente", "");

                startActivity(i);
            }
        });

        return Re;

    }
}