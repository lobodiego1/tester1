package com.lobo.cieloapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class ProductosFragment extends Fragment implements SelectListener {

    RecyclerView rv1;
    private RequestQueue queue;
    JSONArray mJsonArrayProperty;
    Button btnAgregarProducto;
    
    public ProductosFragment() {
        // Required empty public constructor
    }

    @Override
    public void onItemClicked(ListenerBean myModel) {
        Intent i = new Intent(getActivity(), GestionProductosActivity.class);
        i.putExtra("idProducto", myModel.getId());

        i.putExtra("nombre", myModel.getNombre());
        i.putExtra("descripcion", myModel.getStatusPedido());
        i.putExtra("precio", myModel.getPrecioProducto());

        startActivity(i);
    }

    @Override
    public void onItemClickedAux(ListenerBean myModel) {

        this.agregarAlCArrito(myModel.getId(), myModel.getNombre());
    }



    private class AdaptadorProductos extends RecyclerView.Adapter<ProductosFragment.AdaptadorProductos.AdaptadorProductossHolder>{

        private SelectListener listener;

        public AdaptadorProductos(SelectListener listener) {
            this.listener = listener;
        }

        @NonNull
        @Override
        public ProductosFragment.AdaptadorProductos.AdaptadorProductossHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ProductosFragment.AdaptadorProductos.AdaptadorProductossHolder(getLayoutInflater().inflate(R.layout.layout_card_productos, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull ProductosFragment.AdaptadorProductos.AdaptadorProductossHolder holder, int position) {
            holder.imprimir(position);
        }

        @Override
        public int getItemCount() {
            return mJsonArrayProperty.length();
        }

        class AdaptadorProductossHolder extends RecyclerView.ViewHolder{
            TextView txtViewNombreProductos, txtViewPrecio;
            Button btnVerProducto, btnAgregarAlcarrito;

            CardView card;
            public AdaptadorProductossHolder(@NonNull View itemView){
                super(itemView);

                txtViewNombreProductos = itemView.findViewById(R.id.txtViewNombreProductos);
                txtViewPrecio = itemView.findViewById(R.id.txtViewPrecio);
                btnVerProducto = itemView.findViewById(R.id.btnVerProducto);
                btnAgregarAlcarrito = itemView.findViewById(R.id.btnAgregarAlcarrito);
                card = itemView.findViewById(R.id.cardViewProductos);
            }

            public void imprimir(int p) {

                try {
                    JSONObject mJsonObjectProperty = mJsonArrayProperty.getJSONObject(p);

                    txtViewNombreProductos.setText(mJsonObjectProperty.getString("nombre"));
                    txtViewPrecio.setText(mJsonObjectProperty.getString("precio"));
                    btnVerProducto.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ListenerBean lista = new ListenerBean();
                            try {
                                lista.setId(mJsonObjectProperty.getString("idProducto"));
                                lista.setNombre(mJsonObjectProperty.getString("nombre"));
                                lista.setPrecioProducto(mJsonObjectProperty.getString("precio"));
                                lista.setStatusPedido(mJsonObjectProperty.getString("descripcion"));
                                listener.onItemClicked(lista);
                            } catch (JSONException e) {
                                Toast.makeText(getActivity(), "try2:"+e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                    btnAgregarAlcarrito.setOnClickListener(new View.OnClickListener(){
                        @Override
                        public void onClick(View v) {
                            ListenerBean lista = new ListenerBean();
                            try {
                                lista.setId(mJsonObjectProperty.getString("idProducto"));
                                lista.setNombre(mJsonObjectProperty.getString("nombre"));
                                lista.setPrecioProducto(mJsonObjectProperty.getString("precio"));
                                lista.setStatusPedido(mJsonObjectProperty.getString("descripcion"));
                                listener.onItemClickedAux(lista);
                            } catch (JSONException e) {
                                Toast.makeText(getActivity(), "try2:"+e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });



                } catch (JSONException e) {
                    Toast.makeText(getActivity(), "try1:"+e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                }
            }

        }
    }
    public void realizarPost(String idCliente) {
        String url = "http://192.168.0.119:8080/get-productos-all";

        Map<String, String> params = new HashMap<String, String>();
        params.put("idCliente", idCliente);

        JSONObject jsonObj = new JSONObject(params);

        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    //JSONObject jsonObjCompra = response.getJSONObject("response");
                    mJsonArrayProperty = response.getJSONArray("listResponse");
                    rv1.setAdapter(new ProductosFragment.AdaptadorProductos(ProductosFragment.this));

                } catch (JSONException e) {
                    MyToast.showToastInfo(getActivity(), "e:"+e.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                MyToast.showToastInfo(getActivity(), "product3o:"+error.getMessage());
            }
        });
        queue.add(postRequest);
    }


    public void agregarAlCArrito(String idProducto, String nombre) {
        String url = "http://192.168.0.119:8080/agregar-carrito-id-cliente";

        Map<String, String> params = new HashMap<String, String>();
        params.put("idProducto", idProducto);
        params.put("nombre", nombre);

        JSONObject jsonObj = new JSONObject(params);

        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObj, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                    MyToast.showToastInfo(getActivity(), "exitoso:");

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                MyToast.showToastInfo(getActivity(), "error producto agregar:"+error.getMessage());
            }
        });
        queue.add(postRequest);
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        queue = Volley.newRequestQueue(getActivity());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View Re = inflater.inflate(R.layout.fragment_productos, container, false);
        rv1 = Re.findViewById(R.id.recyclerViewProductos);
        btnAgregarProducto = Re.findViewById(R.id.btnAgregarProducto);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(Re.getContext());
        rv1.setLayoutManager(linearLayoutManager);

        realizarPost("1");

        btnAgregarProducto.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), GestionProductosActivity.class);
                i.putExtra("idProducto", "");

                startActivity(i);
            }
        });
        return Re;
    }
}