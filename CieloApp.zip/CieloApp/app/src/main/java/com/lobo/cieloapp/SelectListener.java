package com.lobo.cieloapp;

public interface SelectListener {
    void onItemClicked(ListenerBean myModel);


    void onItemClickedAux(ListenerBean myModel);
}
