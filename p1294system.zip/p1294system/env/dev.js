var Environment = {    
    DIV_CONTENT_ADMIN: "#div_content_admin",
    DIV_CONTENT_PUBLIC: "#div_content"
};