var Environment = {
    DIV_CONTENT_PUBLIC: ""
};