var Ventas = {
    viewVentas: function(){
        $(Environment.DIV_CONTENT_ADMIN).load(Paths.viewRealizarVenta.url, function(e){
            
        });
    },
    searchVentas: function(){
        $(Environment.DIV_CONTENT_ADMIN).load(Paths.viewSearchVenta.url, function(e){
            
        });
    }
};