var Public = {
    init: function(){
        $(Environment.DIV_HEADER_PUBLIC).html("asdasdasd");
    }
};