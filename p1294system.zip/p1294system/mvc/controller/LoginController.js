var Login = {
    LB_USUARIO: "#lb_usuario",
    LB_PASSWORD: "#lb_password",
    INPUT_USUARIO: "#input_users",
    INPUT_PASSWORD: "#input_password",
    init: function(e){
        
    },
    validaUsuario: function(){
        var model = new Object();
        model.USUARIO = $(Login.INPUT_USUARIO).val();
        model.PASSWORD = $(Login.INPUT_PASSWORD).val();
        
        console.log(model);
        
        Util.ajaxConfig.url = "";
        Util.ajaxConfig.type = "POST";
        Util.ajaxConfig.data = {data: JSON.stringify(model)};
        Util.ajaxConfig.success = function (response, textStatus, jqXHR) {
                
        };
        Util.sendAjax(Util.ajaxConfig);
    }
}