var Admin = {
    init: function(e){
        $(Environment.DIV_CONTENT_PUBLIC).load(Paths.view_menu.url,function(e){
            $(Environment.DIV_CONTENT_ADMIN).load(Paths.view_content_admin.url,function(e){
                
            });
        });
        
        
        
    }
}