var Messages = {
    view_usuario: "Usuario",
    view_password: "Contraseña",
};