var Paths = {
    view_public: {url: "mvc/view/public/view_public.html", init: "Public.init()"},
    view_login: {url: "mvc/view/public/view_login.html", init: "Login.init()"},
    view_admin: {url: "mvc/view/public/view_admin.html", init: "Admin.init()"},
    
    view_menu: {url: "mvc/view/admin/header_menu.html"},
    view_content_admin: {url: "mvc/view/admin/home_admin.html"},
    viewRealizarVenta: {url: "mvc/view/ventas/viewVentas.html"},
    viewSearchVenta: {url: "mvc/view/ventas/viewSearchVenta.html"}
};