$(document).ready(function (){
    var sesion = localStorage.getItem(Util.ID_LOCAL_STORAGE_USER);
    var ruta = "";
    if(sesion != null){
        ruta = "view_login";
    }else{
        ruta = "view_admin";
    }
    
    $(Environment.DIV_CONTENT_PUBLIC).load(Paths[ruta].url,function(e){
        Util.callJs(Paths[ruta].init);
    });
    
});
