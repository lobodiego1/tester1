var Util = {
    ID_LOCAL_STORAGE_USER: 'usuario-aplication',
    SELECT_ONE_ELEMENT: "",
    SELECT_NO_APLICA: "-1",
    LENGTH_MIN_PASSWORD: 8,
    LENGTH_MAX_PASSWORD: 12,
    LENGTH_MAX_TEXTAREA: 5000,
    MAX_SIZE_FILES: 5242880,
    PDF_EXTENSION: "pdf",
    createElement: function (tag) {
        return document.createElement(tag);
    },
    contentData: function (url, callback) {
        var data = Util.createElement("div");
        $(data).html("");
        $(data).attr("class", "row");
        $(data).load(url, callback);
        return data;
    },
    ajaxConfig: {
        url: "",
        type: 'POST',
        error: function (jqXHR, textStatus, errorThrown) {
            Dialog.hideDiaglogLoading();
            //Dialog.showMessage(Messages.view_error + " " + textStatus + " - " + errorThrown);
        },
        beforeSend: function (xhr) {
            Dialog.showDiaglogLoading();
        },
        dataType: "json",
        success: function (data, textStatus, jqXHR) {
        },
        data: null,
        complete: function (xhr, status) {
            Dialog.hideDiaglogLoading();
            $(".btn.btn-primary.disabled").removeClass("disabled");
        }
    },
    sendAjax: function (cfg) {
        $.ajax(cfg);
        cfg.data = {};
        Util.ajaxConfig.contentType = undefined;
        Util.ajaxConfig.processData = undefined;
    },
    getStatus: function (status) {
        if (status === EstadoEnum.ACTIVO.ID)
            return EstadoEnum.ACTIVO.DESCR;
        return EstadoEnum.INACTIVO.DESCR;
    },

    $get: function (name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
                results = regex.exec(location.search);
        return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },
    callJs: function (str) {
        //$("body").remove("#script-util");
        var script = Util.createElement("script");
        //$(script).attr("id", "script-modal");
        $(script).append(str);
        $("body").append(script);
        //$("body").remove("#script-util");
    },
    getUser: function () {
        return JSON.parse(localStorage.getItem(Util.ID_LOCAL_STORAGE_USER));
    },
    getCloseUsuario: function () {
        localStorage.removeItem(Util.ID_LOCAL_STORAGE_USER);
        Util.redireccionar(Paths.view_login);
    },
    getSessionUsuario: function () {
        var session = localStorage.getItem(Util.ID_LOCAL_STORAGE_USER);
        if (session === null || session === '') {
            Util.redireccionar(Paths.view_login);
        }
    },
    redireccionar: function (page) {
        $(Enviroment.main_content).load(page.url, function () {
            Util.callJs(page.init);
        });
    },
    createSelect: function (data, indexValue, indexText, componentId, textFirstElement, isRequerido, isDisabled, dataSelected, eventOnchange) {
        var component = "<select class='form-control' id='" + componentId + "' style='margin-right: 10px;' " + (isRequerido ? "data-isRequerido='1'" : "") + " " + (isDisabled ? 'disabled' : '') + " " + (eventOnchange === undefined ? "" : "onchange='" + eventOnchange + "'") + ">";
        component += "<option value=''>" + textFirstElement + "</option>";
        if (data !== undefined) {
            for (var i in data) {
                var datos = Object.keys(data[i]).map(function (key) {
                    return data[i][key];
                });
                component += "<option value='" + datos[indexValue] + "' " + (dataSelected === datos[indexValue] ? 'selected' : '') + " >" + datos[indexText] + "</option>";
            }
        }
        component += "</select>";
        return component;
    },
    reload: function () {
        location.reload();
    },
    getIEVersion: function () {
        var match = navigator.userAgent.match(/(?:MSIE |Trident\/.*; rv:)(\d+)/);
        return match ? parseInt(match[1]) : undefined;
    },
    getEdgeVersion: function () {
        var match = navigator.userAgent.match(/.* Edge\/([0-9.]+)$/);
        return match ? parseInt(match[1]) : undefined;
    },
    getFileExtension: function (filename) {
        return (/[.]/.exec(filename)) ? /[^.]+$/.exec(filename)[0] : undefined;
    },
    validarCampoRequerido: function(id){
        var valor = $(id).val();
        var bnd = true;
        if(valor == ''){
            $(id).addClass("css-error-form-option");
            bnd = false;
        }else{
            $(id).removeClass("css-error-form-option");
        }
        
        return bnd;
    },
    copyToClipboard: function(elemento){
        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val(elemento).select();
        document.execCommand("copy");
        $temp.remove();
    }
};