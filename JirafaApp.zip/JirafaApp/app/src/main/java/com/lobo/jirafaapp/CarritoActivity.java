package com.lobo.jirafaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class CarritoActivity extends AppCompatActivity implements SelectListener {

    RecyclerView rv1;
    TextView mensajeSeguimiento;
    Button btnComprarCarrito;
    String []producto = { "producto 1","producto2"};
    String []precio = { "$90","$45"};

    int []fotos = {R.drawable.ic_launcher_background, R.drawable.ic_launcher_foreground};
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrito);

        rv1 = findViewById(R.id.recyclerPedidosProducto);
        mensajeSeguimiento = findViewById(R.id.txtSeguimientoEnvio);
        btnComprarCarrito = findViewById(R.id.btnComprarCarrito);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        rv1.setLayoutManager(linearLayoutManager);

        rv1.setAdapter(new CarritoActivity.AdaptadorPedidos(this));

        mensajeSeguimiento.setVisibility(View.INVISIBLE);

        btnComprarCarrito.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                mensajeSeguimiento.setVisibility(View.VISIBLE);
            }
        });
    }


    @Override
    public void onItemClicked(ListenerBean myModel) {
        Toast.makeText(this, "producto:"+myModel.getIdProducto(), Toast.LENGTH_SHORT).show();
    }

    private class AdaptadorPedidos extends RecyclerView.Adapter<CarritoActivity.AdaptadorPedidos.AdaptadorPedidosHolder>{


        private SelectListener listener;

        public AdaptadorPedidos(SelectListener listener) {
            this.listener = listener;
        }

        @NonNull
        @Override
        public CarritoActivity.AdaptadorPedidos.AdaptadorPedidosHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new CarritoActivity.AdaptadorPedidos.AdaptadorPedidosHolder(getLayoutInflater().inflate(R.layout.layout_card_productos_pedidos, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull CarritoActivity.AdaptadorPedidos.AdaptadorPedidosHolder holder, int position) {
            holder.imprimir(position);
        }

        @Override
        public int getItemCount() {
            return producto.length;
        }

        class AdaptadorPedidosHolder extends RecyclerView.ViewHolder{
            ImageView imageProductos;
            TextView txtNombreP, txtPrecioProducto;

            CardView card;
            public AdaptadorPedidosHolder(@NonNull View itemView){
                super(itemView);
                imageProductos = itemView.findViewById(R.id.imageProductoPedidos);
                txtNombreP = itemView.findViewById(R.id.txtViewNombreProductoPedidos);
                txtPrecioProducto = itemView.findViewById(R.id.txtViewPrecioProductoPedidos);
                card = itemView.findViewById(R.id.cardViewProductoPedidos);
            }

            public void imprimir(int p){
                imageProductos.setImageResource(fotos[p]);
                txtNombreP.setText(producto[p]);
                txtPrecioProducto.setText(precio[p]);
                card.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ListenerBean lista = new ListenerBean();
                        lista.setIdProducto(producto[p]);
                        listener.onItemClicked(lista);
                    }
                });
            }

        }
    }
}