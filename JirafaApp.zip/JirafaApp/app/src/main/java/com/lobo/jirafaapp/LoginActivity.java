package com.lobo.jirafaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class LoginActivity extends AppCompatActivity {

    EditText usuarioLogin;
    EditText contrasena;
    Button btnLogin;
    Button btnOlvidePass;
    Button btnRegistrarme;

    private RequestQueue queue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usuarioLogin = findViewById(R.id.txtUsuario);
        contrasena = findViewById(R.id.txtPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnOlvidePass = findViewById(R.id.btnOlvideLogin);
        btnRegistrarme = findViewById(R.id.btnRegistrarteLogin);

        queue = Volley.newRequestQueue(this);


        btnLogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                RealizarPost();
               // login();
            }
        });

        btnOlvidePass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this, OlvidePassActivity.class);
                startActivity(i);
            }
        });

        btnRegistrarme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this, RegistrarmeActivity.class);
                startActivity(i);
            }
        });

    }

    public void RealizarPost() {
        String url = "http://192.168.0.119:8080/validacion-login";
// POST parameters
        Map<String, String> params = new HashMap<String, String>();


        String usuario = usuarioLogin.getText().toString();
        String pass = contrasena.getText().toString();
        params.put("usuario", usuario);
        params.put("password", pass);


//        Toast.makeText(LoginActivity.this, "PARAMETRO:"+usuario + ":"+pass, Toast.LENGTH_SHORT).show();

        JSONObject jsonObj = new JSONObject(params);

        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObj, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
  //                  Toast.makeText(LoginActivity.this, "TERS:"+response.get("response").toString(), Toast.LENGTH_SHORT).show();

                    if("OK".equals(response.get("response").toString())){
                        Intent i = new Intent(LoginActivity.this, MainActivity.class);
                        i.putExtra("sesionActivar", "si");
                        startActivity(i);
                    }else{
    //                    Toast.makeText(LoginActivity.this,"Usuarios incorrectos", Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(LoginActivity.this, "producto:"+error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        queue.add(postRequest);
    }
    public void login(){
        String usuario = usuarioLogin.getText().toString();
        String pass = contrasena.getText().toString();

        if(usuario.equals("admin") && pass.equals("12345")){
            Intent i = new Intent(LoginActivity.this, MainActivity.class);
            i.putExtra("sesionActivar", "si");
            startActivity(i);
        }else{
            Toast.makeText(LoginActivity.this,"Usuarios incorrectos", Toast.LENGTH_LONG).show();
        }

    }
}