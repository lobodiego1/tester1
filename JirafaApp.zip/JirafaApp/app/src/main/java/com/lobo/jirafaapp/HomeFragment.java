package com.lobo.jirafaapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class HomeFragment extends Fragment implements SelectListener{

    RecyclerView rv1;
    //String []tienda = { "tienda1","tienda2","tienda1","tienda2","tienda1","tienda2","tienda1","tienda2","tienda1","tienda2"};
    //String []distancia = { "30min","10min","30min","10min","30min","10min","30min","10min","30min","10min"};
    Button btnCarrito;

    JSONArray mJsonArrayProperty;

    private RequestQueue queue;

    /*int []fotos = {R.drawable.ic_launcher_background, R.drawable.ic_launcher_foreground,
            R.drawable.ic_launcher_background, R.drawable.ic_launcher_foreground,
            R.drawable.ic_launcher_background, R.drawable.ic_launcher_foreground,
            R.drawable.ic_launcher_background, R.drawable.ic_launcher_foreground,
            R.drawable.ic_launcher_background, R.drawable.ic_launcher_foreground};*/

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        queue = Volley.newRequestQueue(getActivity());

        realizarPost();

    }

    @Override
    public void onItemClicked(ListenerBean myModel) {
        //Detalle de la tienda
        Intent i = new Intent(getActivity(), DetallesActivity.class);
        i.putExtra("usuario", myModel.getId());
        startActivity(i);
    }

    private class AdaptadorTienda extends RecyclerView.Adapter<HomeFragment.AdaptadorTienda.AdaptadorTiendasHolder>{

        private SelectListener listener;

        public AdaptadorTienda(SelectListener listener) {
            this.listener = listener;
        }

        @NonNull
        @Override
        public HomeFragment.AdaptadorTienda.AdaptadorTiendasHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new HomeFragment.AdaptadorTienda.AdaptadorTiendasHolder(getLayoutInflater().inflate(R.layout.layout_card, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull HomeFragment.AdaptadorTienda.AdaptadorTiendasHolder holder, int position) {
            holder.imprimir(position);
        }

        @Override
        public int getItemCount() {
            return mJsonArrayProperty.length();
        }

        class AdaptadorTiendasHolder extends RecyclerView.ViewHolder{
            ImageView imageTienda;
            TextView txtNombre, txtTiempo;

            CardView card;
            public AdaptadorTiendasHolder(@NonNull View itemView){
                super(itemView);
                imageTienda = itemView.findViewById(R.id.imageTienda);
                txtNombre = itemView.findViewById(R.id.txtViewNombre);
                txtTiempo = itemView.findViewById(R.id.txtViewDistancia);
                card = itemView.findViewById(R.id.cardViewP);
            }

            public void imprimir(int p) {
                Toast.makeText(getActivity(), "entro imprimir:", Toast.LENGTH_SHORT).show();
                try {
                    JSONObject mJsonObjectProperty = mJsonArrayProperty.getJSONObject(p);

                    Toast.makeText(getActivity(), "entro:"+mJsonObjectProperty.getString("nombre"), Toast.LENGTH_SHORT).show();

                    Picasso.get().load(mJsonObjectProperty.getString("urlImagen")).into(imageTienda);

                    txtNombre.setText(mJsonObjectProperty.getString("nombre"));
                    txtTiempo.setText(mJsonObjectProperty.getString("distancia"));
                    card.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ListenerBean lista = new ListenerBean();
                            try {
                                lista.setId(mJsonObjectProperty.getString("idTienda"));
                                listener.onItemClicked(lista);
                            } catch (JSONException e) {
                                Toast.makeText(getActivity(), "try2:"+e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                                throw new RuntimeException(e);
                            }
                        }
                    });

                } catch (JSONException e) {
                    Toast.makeText(getActivity(), "try1:"+e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                    throw new RuntimeException(e);
                }
            }

        }
    }
    public void realizarPost() {
        String url = "http://192.168.0.119:8080/lista-tienda-activas";

        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    Toast.makeText(getActivity(), "try:"+response.getJSONArray("listResponse").toString(), Toast.LENGTH_SHORT).show();
                    mJsonArrayProperty = response.getJSONArray("listResponse");
                    rv1.setAdapter(new HomeFragment.AdaptadorTienda(HomeFragment.this));

                } catch (JSONException e) {
                    Toast.makeText(getActivity(), "try:"+e.getMessage(), Toast.LENGTH_SHORT).show();
                    throw new RuntimeException(e);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), "producto:"+error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(postRequest);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View Re = inflater.inflate(R.layout.fragment_home, container, false);
        rv1 = Re.findViewById(R.id.recyclerVPromo);
        btnCarrito = Re.findViewById(R.id.btnCarrito);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(Re.getContext());
        rv1.setLayoutManager(linearLayoutManager);


        btnCarrito.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), CarritoActivity.class);
                i.putExtra("usuario", "actualizar carrito");
                startActivity(i);
            }
        });

        return Re;
    }
}