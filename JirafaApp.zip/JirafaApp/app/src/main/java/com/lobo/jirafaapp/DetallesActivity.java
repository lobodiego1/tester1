package com.lobo.jirafaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DetallesActivity extends AppCompatActivity implements SelectListener{

    RecyclerView rv1;
    String []producto = { "producto 1","producto2"};
    String []precio = { "$90","$45"};

    int []fotos = {R.drawable.ic_launcher_background, R.drawable.ic_launcher_foreground};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles);

        rv1 = findViewById(R.id.recyclerVProducto);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        rv1.setLayoutManager(linearLayoutManager);

        rv1.setAdapter(new DetallesActivity.AdaptadorProductos(this));

        String valor = getIntent().getStringExtra("usuario");
        Toast.makeText(this, "dato:"+valor, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onItemClicked(ListenerBean myModel) {
        Toast.makeText(this, "producto:"+myModel.getIdProducto(), Toast.LENGTH_SHORT).show();
    }

    private class AdaptadorProductos extends RecyclerView.Adapter<DetallesActivity.AdaptadorProductos.AdaptadorProductosHolder>{


        private SelectListener listener;

        public AdaptadorProductos(SelectListener listener) {
            this.listener = listener;
        }


        @NonNull
        @Override
        public DetallesActivity.AdaptadorProductos.AdaptadorProductosHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new DetallesActivity.AdaptadorProductos.AdaptadorProductosHolder(getLayoutInflater().inflate(R.layout.layout_card_productos, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull DetallesActivity.AdaptadorProductos.AdaptadorProductosHolder holder, int position) {
            holder.imprimir(position);
        }

        @Override
        public int getItemCount() {
            return producto.length;
        }

        class AdaptadorProductosHolder extends RecyclerView.ViewHolder{
            ImageView imageProductos;
            TextView txtNombreP, txtPrecioProducto;

            CardView card;
            public AdaptadorProductosHolder(@NonNull View itemView){
                super(itemView);
                imageProductos = itemView.findViewById(R.id.imageProducto);
                txtNombreP = itemView.findViewById(R.id.txtViewNombreProducto);
                txtPrecioProducto = itemView.findViewById(R.id.txtViewPrecioProduc);
                card = itemView.findViewById(R.id.cardViewProductoTienda);
            }

            public void imprimir(int p){
                imageProductos.setImageResource(fotos[p]);
                txtNombreP.setText(producto[p]);
                txtPrecioProducto.setText(precio[p]);
                card.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ListenerBean lista = new ListenerBean();
                        lista.setIdProducto(producto[p]);
                        listener.onItemClicked(lista);
                    }
                });
            }

        }
    }
}