package com.lobo.jirafaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class OlvidePassActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_olvide_pass);
    }
}