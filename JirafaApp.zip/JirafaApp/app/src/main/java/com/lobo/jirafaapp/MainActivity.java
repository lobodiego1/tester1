package com.lobo.jirafaapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.io.*;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String misesion = getIntent().getStringExtra("sesionActivar");
        if(!"si".equals(misesion)){
            // sesion inactiva
            Intent i = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(i);
        }else {

            bottomNavigationView
                    = findViewById(R.id.bottomNavigationView);

            bottomNavigationView
                    .setOnNavigationItemSelectedListener(this);
            bottomNavigationView.setSelectedItemId(R.id.itemHome);
        }
    }

    HomeFragment homeFragment = new HomeFragment();
    SettingFragment settingFragment = new SettingFragment();
    PedidosFragment pedidosFragment = new PedidosFragment();

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.itemHome){
            getSupportFragmentManager().beginTransaction().replace(R.id.flFragment, homeFragment).commit();
            return true;
        }
        if(item.getItemId() == R.id.itemSettings){
            getSupportFragmentManager().beginTransaction().replace(R.id.flFragment, settingFragment).commit();
            return true;
        }
        if(item.getItemId() == R.id.itemPedidos){
            getSupportFragmentManager().beginTransaction().replace(R.id.flFragment, pedidosFragment).commit();
            return true;
        }

        return false;
    }

}