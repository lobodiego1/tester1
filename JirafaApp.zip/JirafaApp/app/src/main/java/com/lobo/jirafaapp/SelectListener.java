package com.lobo.jirafaapp;

public interface SelectListener {
    void onItemClicked(ListenerBean myModel);
}
